# Srm-Clubs
A website that helps students to keep track of all the events that are going on in the college or are yet to come, in one place.

-> Clone the repository

-> Run index.html in browser

### Screenshots
![Screenshot (3)](https://user-images.githubusercontent.com/73234871/161425986-eeff68ef-db3f-4109-97cf-55765e223520.png)

![Screenshot (4)](https://user-images.githubusercontent.com/73234871/161425998-90f9a8df-3c6c-4046-a4a5-129d1ca1f6ae.png)
